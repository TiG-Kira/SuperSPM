const vehicleTypes = [
    { maxSpeed: 5, icon: '🚶', name: '步行', desc: '您可能正在步行' },
    { maxSpeed: 10, icon: '🚶‍♂️', name: '快走/跑步', desc: '您可能在快走或跑步' },
    { maxSpeed: 20, icon: '🚲', name: '自行车', desc: '您可能正在骑自行车' },
    { maxSpeed: 35, icon: '🛵', name: '电动车', desc: '您可能正在骑电动车' },
    { maxSpeed: 50, icon: '🏍️', name: '摩托车', desc: '您可能正在骑摩托车' },
    { maxSpeed: 70, icon: '🚌', name: '城市公交', desc: '您可能在坐公交车' },
    { maxSpeed: 120, icon: '🚗', name: '汽车', desc: '您可能在开车或坐车' },
    { maxSpeed: 200, icon: '🚆', name: '火车', desc: '您可能在坐火车' },
    { maxSpeed: 350, icon: '🚄', name: '高铁', desc: '您可能在坐高铁' },
    { maxSpeed: Infinity, icon: '✈️', name: '飞机', desc: '您可能在坐飞机' }
];

let lastSpeeds = [];
const MAX_SAMPLES = 10;

function getStableSpeed(currentSpeed) {
    lastSpeeds.push(currentSpeed);
    if (lastSpeeds.length > MAX_SAMPLES) {
        lastSpeeds.shift();
    }
    const sorted = [...lastSpeeds].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function detectVehicle(speedKmh) {
    for (const vehicle of vehicleTypes) {
        if (speedKmh < vehicle.maxSpeed) {
            return vehicle;
        }
    }
    return vehicleTypes[vehicleTypes.length - 1];
}

function formatSpeed(speed) {
    return speed.toFixed(1);
}

function formatDistance(distance) {
    if (distance < 1000) {
        return distance.toFixed(0) + ' m';
    }
    return (distance / 1000).toFixed(2) + ' km';
}

function updateUI(data) {
    const currentSpeed = data.currentSpeed;
    const speedKmh = currentSpeed * 3.6;
    const stableSpeed = getStableSpeed(speedKmh);

    document.getElementById('speedValue').textContent = formatSpeed(speedKmh);
    document.getElementById('maxSpeed').textContent = formatSpeed(data.maxSpeed * 3.6) + ' km/h';
    document.getElementById('avgSpeed').textContent = formatSpeed(data.avgSpeed * 3.6) + ' km/h';
    document.getElementById('totalDistance').textContent = formatDistance(data.totalDistance);
    document.getElementById('sensorMode').textContent = data.isSensorMode ? '传感器' : 'GPS';

    if (!data.isRecording && speedKmh < 1) {
        document.getElementById('vehicleIcon').textContent = '⏸️';
        document.getElementById('vehicleName').textContent = '等待测速';
        document.getElementById('vehicleDesc').textContent = '点击开始测速后自动识别';
    } else {
        const vehicle = detectVehicle(stableSpeed);
        document.getElementById('vehicleIcon').textContent = vehicle.icon;
        document.getElementById('vehicleName').textContent = vehicle.name;
        document.getElementById('vehicleDesc').textContent = vehicle.desc;
    }
}

window.onSpeedUpdate = function(data) {
    updateUI(data);
};

window.addEventListener('load', function() {
    if (typeof SpeedData !== 'undefined') {
        const initialData = {
            currentSpeed: SpeedData.getCurrentSpeed(),
            maxSpeed: SpeedData.getMaxSpeed(),
            avgSpeed: SpeedData.getAvgSpeed(),
            totalDistance: SpeedData.getTotalDistance(),
            isRecording: SpeedData.isRecording(),
            isSensorMode: SpeedData.isSensorMode()
        };
        updateUI(initialData);
    }
});
